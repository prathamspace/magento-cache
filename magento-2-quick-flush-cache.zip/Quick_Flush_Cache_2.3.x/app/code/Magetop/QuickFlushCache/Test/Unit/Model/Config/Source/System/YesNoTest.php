<?php
/**
 * Magetop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magetop.com license that is
 * available through the world-wide-web at this URL:
 * https://www.magetop.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category  Magetop
 * @package   Magetop_QuickFlushCache
 * @copyright Copyright (c) Magetop (https://www.magetop.com/)
 * @license   https://www.magetop.com/LICENSE.txt
 */

namespace Magetop\QuickFlushCache\Test\Unit\Model\Config\Source\System;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magetop\QuickFlushCache\Model\Config\Source\System\YesNo;
use PHPUnit\Framework\TestCase;

/**
 * Class YesNoTest
 * @package Magetop\QuickFlushCache\Test\Unit\Model\Config\Source\System
 */
class YesNoTest extends TestCase
{
    /**
     * @var YesNo
     */
    protected $model;

    protected function setUp()
    {
        $helper = new ObjectManager($this);

        $this->model = $helper->getObject(
            YesNo::class
        );
    }

    /**
     * Test to actions option array
     */
    public function testToOptionArray()
    {
        $expectResult = [
            [
                'value' => 1,
                'label' => __('Yes (Automatic)')
            ],
            [
                'value' => 2,
                'label' => __('Yes (Manual)')
            ],
            [
                'value' => 0,
                'label' => __('No')
            ]
        ];
        $actualResult = $this->model->toOptionArray();
        $this->assertEquals($expectResult, $actualResult);
    }
}
