<?php
/**
 * Magetop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magetop.com license that is
 * available through the world-wide-web at this URL:
 * https://www.magetop.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magetop
 * @package     Magetop_QuickFlushCache
 * @copyright   Copyright (c) Magetop (https://www.magetop.com/)
 * @license     https://www.magetop.com/LICENSE.txt
 */

namespace Magetop\QuickFlushCache\Plugin\Model\System\Message;

use Magento\AdminNotification\Model\System\Message\CacheOutdated as SystemCacheOutdated;
use Magetop\QuickFlushCache\Helper\Data as HelperData;
use Magetop\QuickFlushCache\Model\Config\Source\System\YesNo;

/**
 * Class CacheOutdated
 * @package Magetop\QuickFlushCache\Plugin\Model\System\Message
 */
class CacheOutdated
{
    /**
     * @var HelperData
     */
    protected $_helperData;

    /**
     * CacheOutdated constructor.
     *
     * @param HelperData $helperData
     */
    public function __construct(
        HelperData $helperData
    ) {
        $this->_helperData = $helperData;
    }

    /**
     * @param SystemCacheOutdated $subject
     * @param $result
     * @SuppressWarnings(Unused)
     *
     * @return mixed
     */
    public function afterGetText(SystemCacheOutdated $subject, $result)
    {
        if ($this->_helperData->isEnabledFlushCache() === YesNo::MANUAL) {
            $result .= ' <a id="mp-qfc-flush-cache" href="#">' . __('Flush Now!') . '</a>';
        }

        return $result;
    }
}
